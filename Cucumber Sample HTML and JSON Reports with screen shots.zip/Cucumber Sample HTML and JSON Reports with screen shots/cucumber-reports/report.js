$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("basicTest.feature");
formatter.feature({
  "line": 1,
  "name": "Login",
  "description": "verify the login functionality",
  "id": "login",
  "keyword": "Feature"
});
formatter.before({
  "duration": 5661356400,
  "status": "passed"
});
formatter.scenario({
  "line": 4,
  "name": "Login Test scenario-1",
  "description": "",
  "id": "login;login-test-scenario-1",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "i am on Login page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 6,
      "value": "#When i enter valid login credentials"
    }
  ],
  "line": 7,
  "name": "i should login successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "seleniumTest.i_am_on_Login_page()"
});
formatter.result({
  "duration": 2999550100,
  "status": "passed"
});
formatter.match({
  "location": "seleniumTest.i_should_login_successfully()"
});
formatter.result({
  "duration": 786527200,
  "status": "passed"
});
formatter.after({
  "duration": 120800,
  "status": "passed"
});
formatter.before({
  "duration": 3923579100,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Login Test scenario-2",
  "description": "",
  "id": "login;login-test-scenario-2",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "i am on Login page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 12,
      "value": "#When i enter valid login credentials"
    }
  ],
  "line": 13,
  "name": "i should login successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "seleniumTest.i_am_on_Login_page()"
});
formatter.result({
  "duration": 2756559000,
  "status": "passed"
});
formatter.match({
  "location": "seleniumTest.i_should_login_successfully()"
});
formatter.result({
  "duration": 980217900,
  "status": "passed"
});
formatter.after({
  "duration": 35100,
  "status": "passed"
});
formatter.before({
  "duration": 3414434400,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "Login Test scenario-3",
  "description": "",
  "id": "login;login-test-scenario-3",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 17,
  "name": "i am on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "i enter valid login credentials",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "i should login successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "seleniumTest.i_am_on_Login_page()"
});
formatter.result({
  "duration": 2266325000,
  "status": "passed"
});
formatter.match({
  "location": "seleniumTest.i_enter_valid_login_credentials()"
});
formatter.result({
  "duration": 32480600,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"xpath\",\"selector\":\"//dev//fed\"}\n  (Session info: chrome\u003d84.0.4147.125)\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.7.1\u0027, revision: \u00278a0099a\u0027, time: \u00272017-11-06T21:01:39.354Z\u0027\nSystem info: host: \u0027LTPBAN252092840\u0027, ip: \u0027192.168.43.232\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_231\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 84.0.4147.125, chrome: {chromedriverVersion: 83.0.4103.39 (ccbf011cb2d2b..., userDataDir: C:\\Users\\MILIND~1.KAM\\AppDa...}, goog:chromeOptions: {debuggerAddress: localhost:62597}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:virtualAuthenticators: true}\nSession ID: 01e813518f182c4da547f5a0399f8da0\n*** Element info: {Using\u003dxpath, value\u003d//dev//fed}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:164)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:600)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:370)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:472)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:361)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:362)\r\n\tat com.test.seleniumGlueCode.seleniumTest.i_enter_valid_login_credentials(seleniumTest.java:36)\r\n\tat ✽.When i enter valid login credentials(basicTest.feature:18)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "seleniumTest.i_should_login_successfully()"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded0.png");
formatter.write("URL at failure: https://www.google.com/?gws_rd\u003dssl");
formatter.after({
  "duration": 260356800,
  "status": "passed"
});
formatter.before({
  "duration": 3506070500,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Login Test scenario-4",
  "description": "",
  "id": "login;login-test-scenario-4",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "i am on Login page",
  "keyword": "Given "
});
formatter.step({
  "comments": [
    {
      "line": 24,
      "value": "#When i enter valid login credentials"
    }
  ],
  "line": 25,
  "name": "i should login successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "seleniumTest.i_am_on_Login_page()"
});
formatter.result({
  "duration": 3163607600,
  "status": "passed"
});
formatter.match({
  "location": "seleniumTest.i_should_login_successfully()"
});
formatter.result({
  "duration": 791500000,
  "status": "passed"
});
formatter.after({
  "duration": 50400,
  "status": "passed"
});
formatter.before({
  "duration": 4373271600,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "Login Test scenario-5",
  "description": "",
  "id": "login;login-test-scenario-5",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "i am on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "i enter valid login credentials test",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "i should login successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "seleniumTest.i_am_on_Login_page()"
});
formatter.result({
  "duration": 2497010700,
  "status": "passed"
});
formatter.match({
  "location": "seleniumTest.i_enter_valid_login_credentials_test()"
});
formatter.result({
  "duration": 21351100,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"xpath\",\"selector\":\"//dev\"}\n  (Session info: chrome\u003d84.0.4147.125)\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.7.1\u0027, revision: \u00278a0099a\u0027, time: \u00272017-11-06T21:01:39.354Z\u0027\nSystem info: host: \u0027LTPBAN252092840\u0027, ip: \u0027192.168.43.232\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_231\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 84.0.4147.125, chrome: {chromedriverVersion: 83.0.4103.39 (ccbf011cb2d2b..., userDataDir: C:\\Users\\MILIND~1.KAM\\AppDa...}, goog:chromeOptions: {debuggerAddress: localhost:62654}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:virtualAuthenticators: true}\nSession ID: 76876ebf55ac93ed95113715f600389e\n*** Element info: {Using\u003dxpath, value\u003d//dev}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:164)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:600)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:370)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:472)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:361)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:362)\r\n\tat com.test.seleniumGlueCode.seleniumTest.i_enter_valid_login_credentials_test(seleniumTest.java:44)\r\n\tat ✽.When i enter valid login credentials test(basicTest.feature:30)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "seleniumTest.i_should_login_successfully()"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded1.png");
formatter.write("URL at failure: https://www.google.com/?gws_rd\u003dssl");
formatter.after({
  "duration": 289519300,
  "status": "passed"
});
});