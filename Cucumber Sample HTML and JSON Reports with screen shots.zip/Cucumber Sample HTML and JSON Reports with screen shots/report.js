$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("basicTest.feature");
formatter.feature({
  "line": 1,
  "name": "Login",
  "description": "verify the login functionality",
  "id": "login",
  "keyword": "Feature"
});
formatter.before({
  "duration": 4749780200,
  "status": "passed"
});
formatter.scenario({
  "line": 4,
  "name": "Login Test scenario",
  "description": "",
  "id": "login;login-test-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "i am on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "i enter valid login credentials",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "i should login successfully",
  "keyword": "Then "
});
formatter.match({
  "location": "seleniumTest.i_am_on_Login_page()"
});
formatter.result({
  "duration": 12083759100,
  "status": "passed"
});
formatter.match({
  "location": "seleniumTest.i_enter_valid_login_credentials()"
});
formatter.result({
  "duration": 39986000,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"xpath\",\"selector\":\"//dev//fed\"}\n  (Session info: chrome\u003d84.0.4147.125)\nFor documentation on this error, please visit: http://seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.7.1\u0027, revision: \u00278a0099a\u0027, time: \u00272017-11-06T21:01:39.354Z\u0027\nSystem info: host: \u0027LTPBAN252092840\u0027, ip: \u0027192.168.43.232\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_231\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 84.0.4147.125, chrome: {chromedriverVersion: 83.0.4103.39 (ccbf011cb2d2b..., userDataDir: C:\\Users\\MILIND~1.KAM\\AppDa...}, goog:chromeOptions: {debuggerAddress: localhost:53124}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: WINDOWS, platformName: WINDOWS, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:virtualAuthenticators: true}\nSession ID: 46aea675de5e57aaa719b69269464fd9\n*** Element info: {Using\u003dxpath, value\u003d//dev//fed}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:164)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:600)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:370)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:472)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:361)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:362)\r\n\tat com.test.seleniumGlueCode.seleniumTest.i_enter_valid_login_credentials(seleniumTest.java:36)\r\n\tat ✽.When i enter valid login credentials(basicTest.feature:6)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "seleniumTest.i_should_login_successfully()"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded0.png");
formatter.write("URL at failure: https://www.google.com/?gws_rd\u003dssl");
formatter.after({
  "duration": 270629100,
  "status": "passed"
});
});